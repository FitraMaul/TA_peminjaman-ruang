<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- AdminLTE CSS -->
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include '../../partials/navbar1.php'; ?>

        <!-- Content -->
    <div class="container mt-4">
        <h5 class="text-primary">Beranda</h5>
        <br>
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="content-box">
                    <img src="https://via.placeholder.com/80" alt="Icon" class="mb-4">
                    <h4>Selamat datang di Aplikasi Peminjaman Ruang Kelas</h4>
                    <p class="text-muted">Di sini Anda dapat melakukan pengajuan peminjaman ruang kelas ataupun mengelola peminjaman yang ada.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
</body>
</html>
