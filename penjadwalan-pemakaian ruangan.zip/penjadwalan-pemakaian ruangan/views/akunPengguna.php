<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Akun Pengguna</title>
    <!-- Bootstrap 5 CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Custom table styling */
.custom-table {
    background-color: #ffffff;
    border-collapse: separate;
    border-spacing: 0;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Tambahkan efek shadow */
    overflow: hidden;
    margin-top: 20px; /*Beri jarak dengan elemen lainnya*/
}

.custom-table th,
.custom-table td {
    border: none;
    vertical-align: middle;
    text-align: left;
    padding: 10px 15px;
}

.custom-table thead th {
    background-color: #f8f9fa;
    font-weight: bold;
}

.custom-table tbody tr:nth-child(even) {
    background-color: #f9f9f9;
}

.custom-table tbody tr:hover {
    background-color: #f1f1f1;
}
    </style>
</head>
<body>
    <?php include '../partials/navbar.php'; ?>
    
    <!-- Content -->
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="text-primary mb-0">Kelola Akun Pengguna</h5>
            <!-- button tambah akun -->
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahAkunModal">
                <i class="bi bi-person-plus"></i> Tambah Akun
            </button>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="custom-table w-100">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama Lengkap</th>
                                <th>Username</th>
                                <th>Level</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Bagian Umum</td>
                                <td>umum</td>
                                <td>Bagian Umum</td>
                                <td class="text-center">
                                    <button class="btn btn-info btn-sm">Sunting</button>
                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Biro Pendidikan</td>
                                <td>biropend</td>
                                <td>Biro Pendidikan</td>
                                <td class="text-center">
                                    <button class="btn btn-info btn-sm">Sunting</button>
                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Kabag/Kaprodi</td>
                                <td>kabag</td>
                                <td>Kabag/Kaprodi</td>
                                <td class="text-center">
                                    <button class="btn btn-info btn-sm">Sunting</button>
                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>Ahmad Rivaldy S</td>
                                <td>aldy</td>
                                <td>Pengguna Ruangan</td>
                                <td class="text-center">
                                    <button class="btn btn-info btn-sm">Sunting</button>
                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>5</td>
                                <td>User</td>
                                <td>user</td>
                                <td>Pengguna Ruangan</td>
                                <td class="text-center">
                                    <button class="btn btn-info btn-sm">Sunting</button>
                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


<!-- Model Tambah Akun -->
<div class="modal fade" id="tambahAkunModal" tabindex="-1" aria-labelledby="tambahAkunModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahAkunModalLabel">Buat Akun Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="tambahAkunForm">
                    <div class="mb-3">
                        <label for="namaLengkap" class="form-label">Nama Lengkap</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-person"></i></span>
                            <input type="text" class="form-control" id="namaLengkap" placeholder="Nama lengkap" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="namaPengguna" class="form-label">Nama Pengguna</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-person-circle"></i></span>
                            <input type="text" class="form-control" id="namaPengguna" placeholder="Nama pengguna" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="kataSandi" class="form-label">Kata Sandi</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-lock"></i></span>
                            <input type="password" class="form-control" id="kataSandi" placeholder="Kata sandi" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="level" class="form-label">Level</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-layers"></i></span>
                            <select class="form-select" id="level" required>
                                <option value="" disabled selected>Pilih level</option>
                                <option value="Bagian Umum">Bagian Umum</option>
                                <option value="Biro Pendidikan">Biro Pendidikan</option>
                                <option value="Kabag/Kaprodi">Kabag/Kaprodi</option>
                                <option value="Pengguna Ruangan">Pengguna Ruangan</option>
                            </select>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <small class="text-muted">Pastikan data telah terisi dengan benar.</small>
            </div>
        </div>
    </div>
</div>

    <?php include '../partials/footer.php'; ?>

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
</body>
</html>
