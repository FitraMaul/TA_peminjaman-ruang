

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman Kelas</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* styles.css */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-color: #f5f5f5;
}

.container {
    display: flex;
    width: 800px;
    height: 400px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.left-panel {
    flex: 1;
    background: url('https://via.placeholder.com/400') no-repeat center center/cover;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    position: relative;
}

.welcome-text h1 {
    color: white;
    font-size: 2.5em;
    margin: 0;
}

.right-panel {
    flex: 1;
    padding: 20px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
}

.form-container {
    text-align: center;
    width: 100%;
}

.form-container h2 {
    font-size: 1.5em;
    margin-bottom: 20px;
}

form {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 15px;
    width: 100%; /* Form akan menyesuaikan lebar kontainer */
}

input {
    padding: 12px 15px; /* Menambahkan ruang dalam input */
    font-size: 1rem; /* Ukuran teks */
    border: 1px solid #ccc;
    border-radius: 5px;
    width: 80%; /* Lebar input disesuaikan (80% dari kontainer form) */
    box-sizing: border-box; /* Memastikan padding tidak menambah lebar total */
}

button {
    padding: 12px 15px; /* Tinggi tombol */
    font-size: 1rem;
    color: #fff;
    background-color: #00bcd4;
    border: none;
    border-radius: 5px;
    width: 80%; /* Lebar tombol sama dengan input */
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #0097a7;
}

footer {
    font-size: 0.8em;
    color: #888;
    text-align: center;
}

    </style>
</head>
<body>
    <div class="container">
        <div class="left-panel">
            <div class="welcome-text">
                <h1>Selamat datang</h1>
            </div>
        </div>
        <div class="right-panel">
            <div class="form-container">
                <h2>Peminjaman Kelas</h2>
                <form action="#">
                    <input type="text" placeholder="Nama pengguna" required>
                    <input type="password" placeholder="Kata sandi" required>
                    <button type="submit">Masuk</button>
                </form>
            </div>
            <footer>
                <p>© 2018-2021 Pinjam Kelas · Ahmad Rivaldy S</p>
            </footer>
        </div>
    </div>
</body>
</html>
