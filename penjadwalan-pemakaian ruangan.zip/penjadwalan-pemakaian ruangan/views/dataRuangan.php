<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Akun Pengguna</title>
    <!-- Bootstrap 5 CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* Custom table styling */
.custom-table {
    background-color: #ffffff;
    border-collapse: separate;
    border-spacing: 0;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Tambahkan efek shadow */
    overflow: hidden;
    margin-top: 20px; /*Beri jarak dengan elemen lainnya*/
}

.custom-table th,
.custom-table td {
    border: none;
    vertical-align: middle;
    text-align: left;
    padding: 10px 15px;
}

.custom-table thead th {
    background-color: #f8f9fa;
    font-weight: bold;
}

.custom-table tbody tr:nth-child(even) {
    background-color: #f9f9f9;
}

.custom-table tbody tr:hover {
    background-color: #f1f1f1;
}
    </style>
</head>
<body>
    <?php include '../partials/navbar.php'; ?>
    
    <!-- Content -->
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="text-primary mb-0">Kelola Data Ruangan</h5>
            <!-- button tambah ruang -->
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahDataRuangModal">
                Tambahkan Data Ruang
            </button>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="custom-table w-100">
                        <thead>
                            <tr>
                                <th>Nama-Ruang</th>
                                <th>Kelas Yang Menghuni</th>
                                <th>Nama Guru</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Bagian Umum</td>
                                <td>umum</td>
                                <td class="text-center">
                                    <button class="btn btn-info btn-sm">Sunting</button>
                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Biro Pendidikan</td>
                                <td>biropend</td>
                                <td class="text-center">
                                    <button class="btn btn-info btn-sm">Sunting</button>
                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Kabag/Kaprodi</td>
                                <td>kabag</td>
                                <td class="text-center">
                                    <button class="btn btn-info btn-sm">Sunting</button>
                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>Ahmad Rivaldy S</td>
                                <td>aldy</td>
                                <td class="text-center">
                                    <button class="btn btn-info btn-sm">Sunting</button>
                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                </td>
                            </tr>
                            <tr>
                                <td>5</td>
                                <td>User</td>
                                <td>user</td>
                                <td class="text-center">
                                    <button class="btn btn-info btn-sm">Sunting</button>
                                    <button class="btn btn-danger btn-sm">Hapus</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<!-- Modal Tambahkan Data Ruang -->
<div class="modal fade" id="tambahDataRuangModal" tabindex="-1" aria-labelledby="tambahDataRuangLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahDataRuangLabel">Tambahkan Data Ruang</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="tambahDataRuangForm">
                    <!-- Nama Guru -->
                    <div class="mb-3">
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-person"></i></span>
                            <input type="text" class="form-control" id="namaGuru" placeholder="Nama Guru" required>
                        </div>
                    </div>
                    <!-- Pilih Ruang -->
                    <div class="mb-3">
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-stack"></i></span>
                            <select class="form-select" id="ruang" required>
                                <option value="" disabled selected>Ruang</option>
                                <option value="Ruang 101">Ruang 101</option>
                                <option value="Ruang 102">Ruang 102</option>
                                <option value="Ruang 103">Ruang 103</option>
                            </select>
                        </div>
                    </div>
                    <!-- Jurusan -->
                    <div class="mb-3">
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-textarea-t"></i></span>
                            <input type="text" class="form-control" id="jurusan" placeholder="Jurusan" required>
                        </div>
                    </div>
                    <!-- Button Tambahkan -->
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary px-4">Tambahkan</button>
                    </div>
                </form>
            </div>
            <div class="modal-footer text-center">
                <small class="text-muted">Mohon dipastikan kembali data yang telah terisi dengan benar</small>
            </div>
        </div>
    </div>
</div>

    <?php include '../partials/footer.php'; ?>

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
</body>
</html>
