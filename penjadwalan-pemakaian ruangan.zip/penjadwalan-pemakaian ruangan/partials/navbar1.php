<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar Active Link</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom">
        <div class="container"> <!-- Tambahkan class "container" untuk memusatkan isi navbar -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="dataRuangan.php">Data Ruangan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="history.php">History</a>
                    </li>
                </ul>
                <div class="dropdown">
                    <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                        Halo, Bagian Umum
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">
                        <li><a class="dropdown-item" href="#">Informasi Profil</a></li>
                        <li><a class="dropdown-item" href="#">Keluar</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <!-- Bootstrap 5 JS -->
    <script src="http://localhost/penjadwalan-pemakaian%20ruangan/assets/js/bootstrap.bundle.min.js"></script>

    <!-- JavaScript for Active Nav Link -->
    <script>
        // Ambil semua elemen nav-link
        const navLinks = document.querySelectorAll('.nav-link');

        // Dapatkan URL saat ini
        const currentUrl = window.location.href;

        // Loop melalui semua nav-link
        navLinks.forEach(link => {
            // Jika href dari link sesuai dengan URL saat ini
            if (link.href === currentUrl) {
                // Tambahkan class active ke elemen tersebut
                link.classList.add('active');
            } else {
                // Pastikan class active dihapus jika tidak sesuai
                link.classList.remove('active');
            }
        });
    </script>
</body>
</html>
