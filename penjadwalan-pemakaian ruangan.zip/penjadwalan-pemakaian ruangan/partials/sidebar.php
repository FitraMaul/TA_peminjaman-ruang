<style>

/* Hapus shadow sidebar */
.main-sidebar {
    box-shadow: none !important;
}

/* Hapus shadow elemen navbar */
.main-header {
    box-shadow: none !important;
}

/* Hapus shadow pada kontainer dan elemen lainnya */
.card, .dropdown-menu, .modal-content, .navbar {
    box-shadow: none !important;
}

/* Style brand logo */
.brand-link {
    background-color: #7FF094 !important;
    color: #4b4b4b !important;
    box-shadow: none !important;
}
</style>

<aside class="main-sidebar sidebar-light-primary elevation-4" style="background-color: #fff;">
    <!-- Brand Logo -->
    <a href="#" class="brand-link" style="background-color: #7FF094; color: #4b4b4b; box-shadow: none;">
        <span class="brand-text font-weight-bold">AdminLTE 4</span>
    </a>
    <!-- Sidebar -->
    <div class="sidebar">
        <!-- User Info -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex align-items-center">
            <div class="image">
                <i class="fas fa-user-circle fa-2x text-dark" style="display: inline-block;"></i>
            </div>
            <div class="info pl-2">
                <a href="#" class="d-block text-dark">
                    Admin
                    <span class="d-block text-sm text-muted">Halaman Data Jadwal</span>
                </a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <?php 
                // Ambil nama file yang sedang diakses
                $current_page = basename($_SERVER['PHP_SELF']); 
            ?>
            <ul class="nav nav-pills nav-sidebar flex-column" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link <?= $current_page == 'dashboard.php' ? 'active' : '' ?>" style="color: #4b4b4b;">
                        <i class="nav-icon fas fa-home-alt text-dark"></i>
                        <p>HOME</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../views/viewsDataKelas.php" class="nav-link <?= $current_page == 'viewsDataKelas.php' ? 'active' : '' ?>" style="color: #4b4b4b;">
                        <i class="nav-icon fas fa-th text-dark"></i>
                        <p>DATA KELAS</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../views/viewsDataGuru.php" class="nav-link <?= $current_page == 'viewsDataGuru.php' ? 'active' : '' ?>" style="color: #4b4b4b;">
                        <i class="nav-icon fas fa-copy text-dark"></i>
                        <p>DATA GURU</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="mataPelajaran.php" class="nav-link <?= $current_page == 'mataPelajaran.php' ? 'active' : '' ?>" style="color: #4b4b4b;">
                        <i class="nav-icon fas fa-layer-group text-dark"></i>
                        <p>MATA PELAJARAN</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="penjadwalan.php" class="nav-link <?= $current_page == 'penjadwalan.php' ? 'active' : '' ?>" style="color: #4b4b4b;">
                        <i class="nav-icon fas fa-edit text-dark"></i>
                        <p>PENJADWALAN</p>
                    </a>
                </li>
                <li class="nav-item mt-4">
                    <a href="../auth/logout.php" class="nav-link text-danger">
                        <i class="nav-icon fas fa-sign-out-alt"></i>
                        <p>LOGOUT</p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
