<!-- Footer -->
<footer>
        <p>© 2018-2024 Pinjam Kelas · Ahmad Rivaldy S</p>
    </footer>